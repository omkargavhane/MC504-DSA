/*Name : Omkar Santosh Gavhane
Roll No : 2111MC08
MC504-Assignment 1
*/
#include<stdio.h>
int main(){
	float f,d;
	printf("Enter temperature in fahreheit:");
	scanf("%f",&f);
	d=(f-32)*5/9;
	printf("Temperature in degree celcius %f C",d);
	return(0);
}
