/*Name : Omkar Santosh Gavhane
Roll No : 2111MC08
MC504-Assignment 1
*/
#include<stdio.h>
int main(){
	int no;
	printf("x:");
	scanf("%d",&no);
	if(no%2==0)
		printf("The number %d is even",no);
	else
		printf("The number %d is odd",no);
	return(0);
}
